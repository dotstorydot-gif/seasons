# Deployment Documentation - SEASONS BY NATURE

This document contains the final steps to point your domain `seasonsbynature.com` to your live website using **cPanel**.

## 1. Domain & DNS Configuration (Bluehost)

Login to your **Bluehost cPanel** and update the DNS records for `seasonsbynature.com` to point to your server IP:

### A Records (Critical)

| Type | Host | Points to | TTL |
| :--- | :--- | :--- | :--- |
| A | @ | `66.81.203.198` | 2 Hours |
| A | www | `66.81.203.198` | 2 Hours |

---

## 2. Deploying via cPanel "Setup Node.js App"

Follow these steps to host your Next.js application:

### Step 1: Upload your Code

1. Compress your project folder (except `node_modules` and `.next`) into a **.zip** file.
2. Open **cPanel > File Manager**.
3. Upload the `.zip` to your home directory (e.g., `/home/username/seasonsweb`).
4. **Extract** the files into that folder.

### Step 2: Create the Node.js Application

1. Go to **cPanel > Setup Node.js App**.
2. Click **Create Application**.
3. **Node.js Version**: Select **18.x** or **20.x**.
4. **Application Mode**: Development (switch to Production later).
5. **Application Root**: The path to your folder (e.g., `seasonsweb`).
6. **Application URL**: Select `seasonsbynature.com`.
7. **Startup File**: Type `node_modules/next/dist/bin/next`.
8. Click **Create**.

### Step 3: Install Dependencies & Build

1. Once the app is created, copy the **Command for entering to the virtual environment** (it looks like `source /home/username/nodevenv/.../bin/activate`).
2. Go to **cPanel > Terminal**.
3. Paste that command and hit Enter.
4. Run these commands in the terminal:

    ```bash
    cd seasonsweb
    npm install
    npm run build
    ```

### Step 4: Restart the App

1. Go back to **Setup Node.js App**.
2. Click the **Restart** button for your application.

---
**Tip**: If you do not see "Setup Node.js App" in your cPanel, please contact Bluehost Support and ask them to enable the **Node.js Selector** for your account.
